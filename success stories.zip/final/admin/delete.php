<?php
@session_start();
include("include/connect.php");
$db=new Database();
?>
<?php
if(!empty($_GET['val']))
{
$query_data="DELETE FROM `write_for` WHERE id='".$_GET['val']."'";
$run_deleted=$db->deleted($query_data);	
	if($run_deleted)
	{
		echo '<script>alert("Data Has Been Deleted..."); history.go(-1);</script>';
	}
	else
	{
	echo '<script>alert("Please Try Again.."); history.go(-1);</script>';	
		
	}
}

if(!empty($_GET['val1']))
{
$query_data="DELETE FROM `subscriber` WHERE id='".$_GET['val1']."'";
$run_deleted=$db->deleted($query_data);	
	if($run_deleted)
	{
		echo '<script>alert("Data Has Been Deleted..."); history.go(-1);</script>';
	}
	else
	{
	echo '<script>alert("Please Try Again.."); history.go(-1);</script>';	
		
	}
}

if(!empty($_GET['val2']))
{
$query_data="DELETE FROM `blog` WHERE id='".$_GET['val2']."'";
$run_deleted=$db->deleted($query_data);	
	if($run_deleted)
	{
		echo '<script>alert("Data Has Been Deleted..."); history.go(-1);</script>';
	}
	else
	{
	echo '<script>alert("Please Try Again.."); history.go(-1);</script>';	
		
	}
}


if(!empty($_GET['cont']))
{
$query_data="DELETE FROM `comment` WHERE id='".$_GET['cont']."'";
$run_deleted=$db->deleted($query_data);	
	if($run_deleted)
	{
		echo '<script>alert("Data Has Been Deleted..."); history.go(-1);</script>';
	}
	else
	{
	echo '<script>alert("Please Try Again.."); history.go(-1);</script>';	
		
	}
}

if(!empty($_GET['reg']))
{
$query_data="DELETE FROM `user_detail` WHERE id='".$_GET['reg']."'";
$run_deleted=$db->deleted($query_data);	
	if($run_deleted)
	{
		echo '<script>alert("Data Has Been Deleted..."); history.go(-1);</script>';
	}
	else
	{
	echo '<script>alert("Please Try Again.."); history.go(-1);</script>';	
		
	}
}

if(!empty($_GET['contect']))
{
$query_data="DELETE FROM `contact` WHERE id='".$_GET['contect']."'";
$run_deleted=$db->deleted($query_data);	
	if($run_deleted)
	{
		echo '<script>alert("Data Has Been Deleted..."); history.go(-1);</script>';
	}
	else
	{
	echo '<script>alert("Please Try Again.."); history.go(-1);</script>';	
		
	}
}
?>